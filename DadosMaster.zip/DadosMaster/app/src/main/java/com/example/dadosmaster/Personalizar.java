package com.example.dadosmaster;


import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Personalizar extends AppCompatActivity {

    Spinner dropdownCaras,dropdownDados;
    TextView resultadox;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personalizar);

        resultadox = findViewById(R.id.resultado);


        //NUMERO DE CARAS

        //get the spinner from the xml.
        dropdownCaras = findViewById(R.id.spinner);
        //create a list of items for the spinner.
        String[] items = new String[]{"1", "2", "3","4", "5", "6", "7", "8","9","10"};
        //create an adapter to describe how the items are displayed, adapters are used in several places in android.
        //There are multiple variations of this, but this is the basic variant.
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        //set the spinners adapter to the previously created one.
        dropdownCaras.setAdapter(adapter);


        //NUMERO DE DADOS
        dropdownDados = findViewById(R.id.spinner2);
        //create a list of items for the spinner.
        String[] items2 = new String[]{"1", "2", "3","4", "5"};
        //create an adapter to describe how the items are displayed, adapters are used in several places in android.
        //There are multiple variations of this, but this is the basic variant.
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items2);
        //set the spinners adapter to the previously created one.
        dropdownDados.setAdapter(adapter2);

    }

    public void VolverMenu(View view){

        Intent i = new Intent(this, MainActivity.class);

        startActivity(i);

    }

    public void Lanzar(View view){

        String totalNums = " | ";
        int random = 0;

        String recogerNumCaras = dropdownCaras.getSelectedItem().toString();
        int numCaras = Integer.parseInt(recogerNumCaras);

        String recogerNumDados = dropdownDados.getSelectedItem().toString();
        int numDados = Integer.parseInt(recogerNumDados);


        for(int i = 0; i<numDados; i++){
            random = (int) (numCaras * Math.random()) + 1;

           totalNums = totalNums + random + " | " ;
        }

        resultadox.setText(totalNums);

    }
    public void informacionNumDados (View view){
        AlertDialog alertDialog = new AlertDialog.Builder(Personalizar.this).create();
        alertDialog.setTitle("Numero de dados");
        alertDialog.setMessage("Este es el numero de dados lanzados de forma simultanea");
        alertDialog.show();
    }

    public void informacionNumCaras (View view){
        AlertDialog alertDialog = new AlertDialog.Builder(Personalizar.this).create();
        alertDialog.setTitle("Numero de caras");
        alertDialog.setMessage("Este es el numero de caras que tendrá cada dado");
        alertDialog.show();
    }

}
