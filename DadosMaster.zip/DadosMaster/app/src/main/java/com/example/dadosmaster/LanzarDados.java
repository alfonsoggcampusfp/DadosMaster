package com.example.dadosmaster;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class LanzarDados extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lanzardados);
    }

    //Esta función irá asignada al botón de lanzar el dado
    public void Lanzar(View view){


    }

    public void VolverMenu(View view){

        Intent i = new Intent(this, MainActivity.class);
        finish();
        startActivity(i);


    }

}
